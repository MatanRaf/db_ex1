drop table closed_university;
drop table enrollment_year;
drop table university;
drop table country_entity;

